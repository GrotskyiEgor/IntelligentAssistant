import os
import platform
import subprocess


def open_app(path):
    system = platform.system()
    if system == "Windows":
        os.startfile(path)
    elif system == "Darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen([path])


def open_path(path):
    path = str(path)
    system = platform.system()
    if system == "Windows":
        os.startfile(path)
    elif system == "Darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])


def close_app(app_name) -> bool:
    if platform.system() == "Windows":
        result = subprocess.run(
            ["taskkill", "/F", "/IM", app_name, "/T"],
            capture_output=True, text=True, encoding="cp866", errors="replace",
        )
        return result.returncode == 0
    return subprocess.run(["pkill", "-f", app_name], capture_output=True).returncode == 0